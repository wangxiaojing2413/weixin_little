//app.js
var qcloud = require('./vendor/wafer2-client-sdk/index')
App({

  /**
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
   */
  onLaunch: function () {
    
  },

  globalData: {
    userInfo: null,
    person_one:null,
    person_two:null
  }
})

